Othello Game - Python + Tkinter

To run this game:

1. Make sure you have Python installed on your PC.
   - You can download it from: https://www.python.org/downloads/

2. Open this project in PyCharm.
   - File -> Open -> Select this folder (OthelloGame)

3. Run the file `othello_game.py`

Enjoy the game!
